<?php
header("Location: landing.php");
exit();